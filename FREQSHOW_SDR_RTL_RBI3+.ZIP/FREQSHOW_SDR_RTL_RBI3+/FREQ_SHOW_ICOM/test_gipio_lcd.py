from time import sleep
import sys
import RPi.GPIO as GPIO

# IO NASTAVITVE!

buttongore = 12	 
butonsredina = 16
butondole = 18

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(buttongore, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(butonsredina, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(butondole, GPIO.IN, GPIO.PUD_UP)


# program za testiranje!

while True:
    try:
        print("I1 ( buttongore ): {} I2 ( butonsredina ): {} I3 ( butondole ): {}".format(GPIO.input(buttongore), GPIO.input(butonsredina), GPIO.input(butondole)))
        sleep(0.250)
    except KeyboardInterrupt:
        break
    sleep(0.2)
