#!/bin/sh
# launcher.sh
# navigate to  home directory, then to this directory, then execute python sript, then back home

cd /
cd home/pi/FREQ_SHOW_ICOM
sudo python freqshow.py
cd /
