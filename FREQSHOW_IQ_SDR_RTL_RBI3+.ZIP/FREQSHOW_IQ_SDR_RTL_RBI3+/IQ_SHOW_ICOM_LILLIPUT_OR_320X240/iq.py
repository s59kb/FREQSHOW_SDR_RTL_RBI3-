#!/usr/bin/env python

# Program iq.py - spectrum displays from quadrature sampled IF data.
# Copyright (C) 2013 Martin Ewing
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# Contact the author by e-mail: aa6e@arrl.net
#
# Our goal is to display a zero-centered spectrum and waterfall on small
# computers, such as the BeagleBone Black or the Raspberry Pi, 
# spanning up to +/- 48 kHz (96 kHz sampling) with input from audio card
# or +/- 1.024 MHz from RTL dongle. 
#
# We use pyaudio, pygame, and pyrtlsdr Python libraries, which depend on
# underlying C/C++ libraries PortAudio, SDL, and rtl-sdr.
#

# TO DO:
# Document sources of non-std modules

#-------------------------
import ui, math
import sys, time, threading, os, subprocess
import pygame as pg
import numpy  as np
import iq_dsp as dsp
import iq_wf  as wf
import iq_opt as options
#-----------------------
import RPi.GPIO as GPIO
# IO NASTAVITVE!
UpButton = 12	# pin v RPI3B
SetButton = 16	# pin v RPI3B
DnButton = 18	# pin v RPI3B
GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)
GPIO.setup(UpButton, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(DnButton, GPIO.IN, GPIO.PUD_UP)
GPIO.setup(SetButton, GPIO.IN, GPIO.PUD_UP)
#if GPIO.input(UpButton) == 0:
#        click=self.scale_up        
#if GPIO.input(DnButton) == 0:
#        click=self.controller.toggle_main
#if GPIO.input(SetButton) == 0:
#        click=self.scale_dn
#-----------------------
# Some colors in PyGame style
BLACK =    (  0,   0,   0)
WHITE =    (255, 255, 255)
GREEN =    (  0, 255,   0)
BLUE =     (  0,   0, 255)
RED =      (255,   0,   0)
YELLOW =   (192, 192,   0)
YELLOWNEW =(192, 192,  50)
DARK_RED = (128,   0,   0)
CENT_RED = (128, 100,  50)
LITE_RED = (255, 100, 100)
BGCOLOR =  (255, 230, 200)
NEW_BGCOLOR=  (50,50, 50)
BLUE_GRAY= (100, 100, 180)
ORANGE =   (255, 150,   0)
GRAY =     (192, 192, 192)
# RGBA colors - with alpha
TRANS_YELLOW = (255,255,0,150)
# Adjust for best graticule color depending on display gamma, resolution, etc.
GRAT_COLOR = DARK_RED       # Color of graticule (grid)
GRAT_COLOR_2 = WHITE        # Color of graticule text
TRANS_OVERLAY = TRANS_YELLOW    # for info overlay
TCOLOR2 = ORANGE              # text color on info screen
INFO_CYCLE = 6      # Display frames per help info update 8 BOKI
opt = options.opt   # Get option object from options module
#--------------------------------------------------------------------------------------------------
# print list of parameters to console.
print "identification:", opt.ident
print "source        :", opt.source
print "waterfall     :", opt.waterfall
print "sample rate   :", opt.sample_rate
print "size          :", opt.size
print "buffers       :", opt.buffers
print "taking        :", opt.taking
print "hamlib        :", opt.hamlib
print "hamlib rigtype:", opt.hamlib_rigtype
print "hamlib device :", opt.hamlib_device
print "rtl frequency :", opt.rtl_frequency
print "rtl gain      :", opt.rtl_gain
print "pulse         :", opt.pulse
print "fullscreen    :", opt.fullscreen
print "hamlib intvl  :", opt.hamlib_interval
print "cpu load intvl:", opt.cpu_load_interval
print "wf accum.     :", opt.waterfall_accumulation
print "wf palette    :", opt.waterfall_palette
print "max queue dept:", opt.max_queue
print "PCM290x lagfix:", opt.lagfix
if opt.lcd4:
    print "LCD4 brightnes:", opt.lcd4_brightness
#--------------------------------------------------------------------------------------------------
def quit_all():
    """ Quit pygames and close std outputs somewhat gracefully.
        Minimize console error messages.
    """
    pg.quit()
    try:
        sys.stdout.close()
    except:
        pass
    try:
        sys.stderr.close()
    except:
        pass
    sys.exit()
#--------------------------------------------------------------------------------------------------
class LED(object):
    """ Make an LED indicator surface in pygame environment. 
        Does not include title
    """
    def __init__(self, width):
        """ width = pixels width (& height)
            colors = dictionary with color_values and PyGame Color specs
        """
        self.surface = pg.Surface((width, width))
        self.wd2 = width/2
        #self.colors = colors
        return

    def get_LED_surface(self, color):
        """ Set LED surface to requested color
            Return square surface ready to blit
        """
        self.surface.fill(NEW_BGCOLOR)
        # Always make full-size black circle with no fill.
        pg.draw.circle(self.surface,BLACK,(self.wd2,self.wd2),self.wd2,2)
        if color == None:
            return self.surface
        # Make inset filled color circle.
        pg.draw.circle(self.surface,color,(self.wd2,self.wd2),self.wd2-2,0)
        return self.surface
#--------------------------------------------------------------------------------------------------
class Graticule(object):
    """ Create a pygame surface with freq / power (dB) grid
        and units.
        input: options, pg font, graticule height, width, line color, and text color
    """
    def __init__(self, opt, font, h, w, color_l, color_t):
        self.opt = opt
        self.sp_max = opt.sp_max   # default max value
        self.sp_min = opt.sp_max  # default min value
        self.font = font    # font to use for text
        self.h = h          # height of graph area
        self.w = w          # width
        self.color_l = color_l    # color for lines color_l
        self.color_t = color_t    # color for text color_t
        self.surface = pg.Surface((self.w, self.h))
        return
#----------------------------------------------------------------------------------------------
    global ZoomScrin
    ZoomScrin = 0
    def make(self):
        """ Make or re-make the graticule.
            Returns pygame surface
        """
        self.surface.fill(BLACK)
        for br in range(self.h):
			pg.draw.line(self.surface, (0,0,(br/5)), (0, br-42), ((self.w), br-42),3)
        # yscale is screen units per dB
        yscale = float(self.h)/(self.sp_max-self.sp_min)
        # Define vertical dB scale - draw line each 10 dB.
        scalafont = pg.font.SysFont('sans', 22)
        color_grid = (50,50,0)
        for attn in range(self.sp_min, self.sp_max, 10):#10
            yattn = ((attn - self.sp_min) * yscale) + 70.
            yattnflip = self.h - yattn # screen y coord increases downward
            # Draw a single line, dark red.
            pg.draw.line(self.surface, color_grid, (0, yattnflip-5),(self.w, yattnflip-5),2)
            # Render and blit the dB value at left, just above line
            self.surface.blit(scalafont.render("%3d" % attn, 1, self.color_t),(5, yattnflip))# prikaz db sa leve strane 5
            self.surface.blit(scalafont.render("%3d" % attn, 1, self.color_t),(940, yattnflip))# prikaz db sa desne strane 940      
        # add unit (dB) to topmost label        
        ww, hh = self.font.size("%3d" % attn)
        #self.surface.blit(self.font.render("dB",  1, self.color_t),(5+ww, yattnflip-12))
        # Define freq. scale - draw vert. line at convenient intervals
        #frq_range = float(self.opt.sample_rate)/1000    # kHz total bandwidth
        #----------------------
        if ZoomScrin == 0:
        	frq_range = float(self.opt.sample_rate)/1000    # kHz total bandwidth
        if ZoomScrin == 1:
        	frq_range = float(self.opt.sample_rate/2)/1000    # kHz total bandwidth
        if ZoomScrin == 2:
        	frq_range = float(self.opt.sample_rate/4)/1000    # kHz total bandwidth
        if ZoomScrin == 3:
        	frq_range = float(self.opt.sample_rate/8)/1000    # kHz total bandwidth					
        #----------------------
        xscale = self.w/frq_range               # pixels/kHz x direction
        srate2 = frq_range/2                    # plus or minus kHz
        # Choose the best tick that will work with RTL or sound cards.
        for xtick_max in [ 800.0, 400.0, 200.0, 100.0, 80.0, 50.0, 40.0, 25.0, 20.0, 12.5, 10.0, 6.25, 3.125, 1.56 ]:
            if xtick_max < srate2:
                break
        ticks = [ -xtick_max, -xtick_max/2, -xtick_max/4, 0, xtick_max/4, xtick_max/2, xtick_max]
        for offset in ticks:
            x = offset*xscale + self.w/2					
            pg.draw.line(self.surface, color_grid, (x, 0), (x, self.h),2)
            pg.draw.line(self.surface, color_grid, (x*2, 0), (x*2, self.h),2)		
            if offset == 0:
                offset_txt = "  " + format(offset) 
            else: 
                if offset > 0: 
                    offset_txt = "+" + format(offset)
                else:
                    offset_txt = format(offset)
            self.surface.blit(scalafont.render(offset_txt, 1, self.color_t),(x-18, 444))#(x-20, 445)
        #---------------------------------------------------------------------------------
        #linije vertikalne linije spectrum	
        x = offset*xscale + self.w/10
        pg.draw.line(self.surface, CENT_RED, (x-15, 0), (x-15, self.h))
        pg.draw.line(self.surface, self.color_l, (x, 0), (x, self.h))
        pg.draw.line(self.surface, CENT_RED, (x+14, 0), (x+14, self.h))		
        #---------------------------------------------------------------------------------
        #linija koja odvaja spectrum / waterfall
        scalafont = pg.font.SysFont('sans', 60)
        self.surface.blit(scalafont.render("_______________________________", 2, NEW_BGCOLOR),(0,375))#(0,375)
        #linija koja odvaja spectrum / ispisa frekvenci
        self.surface.blit(scalafont.render("_______________________________", 2, NEW_BGCOLOR),(0,412))#(0,412)		
        #---------------------------------------------------------------------------------
        # Natpis ICOM IC-706MKII S59KB
        WHITENEW = ( 250, 250, 250)			
        icomfont = pg.font.SysFont('sans', 30)
        self.surface.blit(icomfont.render("ICOM IC-706MKII by S59KB", -1, WHITENEW),(305, 0))
        #---------------------------------------------------------------------------------       
        # Natpis S units: i vrednost u brojevima
        sunitfont = pg.font.SysFont('sans', 24)
        s_metarfont = pg.font.SysFont('sans', 40)	
        self.surface.blit(sunitfont.render("S", 0, WHITE),(270, 30))		
        self.surface.blit(s_metarfont.render("[", 0, WHITE),(290, 20))
        self.surface.blit(s_metarfont.render("]", 0, WHITE),(685, 20))
        self.surface.blit(sunitfont.render("dB", 0, WHITE),(700, 30))		
        self.surface.blit(sunitfont.render(" 1     3     5     7      9      20      40      60", 0, WHITE),(297, 55))		
        #s_unitsfont = pg.font.SysFont('sans', 22)		
        #self.surface.blit(s_unitsfont.render("S meter:", 0, WHITE),(205, 40))
		#---------------------------------------------------------------------------------			
        return self.surface
    def set_range(self, sp_min, sp_max):
        """ Set desired range for vertical scale in dB, min. and max.
            0 dB is maximum theoretical response for 16 bit sampling.
            Lines are always drawn at 10 dB intervals. 
        """
        if not sp_max > sp_min:
            print "Invalid dB scale setting requested!"
            quit_all()
        self.sp_max = sp_max
        self.sp_min = sp_min
        return
#--------------------------------------------------------------------------------------------------		
# pretvaranje spice signala u boju
def PeakEfect(colorset):
    if colorset > 150:	
		RColor = (450 - colorset)
		GColor = (450 - colorset)
		BColor = 50
    else:
		RColor = (200)
		GColor = (200)
		BColor = (200)			
    return ( max(0,min(255,RColor)), max(0,min(255,GColor)), max(0,min(255,BColor)) )		
#--------------------------------------------------------------------------------------------------		
# pretvaranje signala u boju
def ColorEfect(colorset):
    palette = 3
    #-----------
    val = colorset - 400
    f = (float(val) - v_min) / (v_max - v_min)     # btw 0 and 1.0
    f *= 2
    f = min(1., max(0., f))
    if palette == 1:
        GColor, BColor = 0, 0
        if f < 0.333:
            RColor = int(f*255*3)
        elif f < 0.666:
            RColor = 200
            GColor = int((f-.333)*255*3)
        else:
            RColor = 200
            GColor = 200
            BColor = int((f-.666)*255*3)
    elif palette == 2:
        bright = min (1.0, f + 0.15)
        tpi = 2 * math.pi
        RColor = (bright * 128 *(1.0 + math.cos(tpi*f)))
        GColor = (bright * 128 *(1.0 + math.cos(tpi*f + tpi/3)))
        BColor = (bright * 128 *(1.0 + math.cos(tpi*f + 2*tpi/3)))
    elif palette == 3: 
        RColor = (400 - colorset)/4
        GColor = (400 - colorset)/4
        BColor = 10
    else:
        print "Invalid palette requested!"
        sys.exit()
    return ( max(0,min(255,RColor)), max(0,min(255,GColor)), max(0,min(255,BColor)) )
#--------------------------------------------------------------------------------------------------
# THREAD: Hamlib, checking Rx frequency, and changing if requested.
if opt.hamlib:
    import Hamlib
    rigfreq_request = None
    rigfreq = 7.0e6             # something reasonable to start
    def updatefreq(interval, rig):
        """ Read/set rig frequency via Hamlib.
            Interval defines repetition time (float secs)
            Return via global variable rigfreq (float kHz)
            To be run as thread.
            (All Hamlib I/O is done through this thread.)
        """
        global rigfreq, rigfreq_request
        rigfreq = float(rig.get_freq()) * 0.001     # freq in kHz
        while True:                     # forever!
            # With KX3 @ 38.4 kbs, get_freq takes 100-150 ms to complete
            # If a new vfo setting is desired, we will have rigfreq_request
            # set to the new frequency, otherwise = None.
            if rigfreq_request:         # ordering of loop speeds up freq change
                if rigfreq_request != rigfreq:
                    rig.set_freq(rigfreq_request*1000.)
                    rigfreq_request = None
            rigfreq = float(rig.get_freq()) * 0.001     # freq in kHz
            time.sleep(interval)
# THREAD: CPU load checking, monitoring cpu stats.
cpu_usage = [0., 0., 0.]
def cpu_load(interval):
    """ Check CPU user and system time usage, along with load average.
        User & system reported as fraction of wall clock time in
        global variable cpu_usage.
        Interval defines sleep time between checks (float secs).
        To be run as thread.
    """
    global cpu_usage
    times_store = np.array(os.times())
    # Will return: fraction usr time, sys time, and 1-minute load average
    cpu_usage = [0., 0., os.getloadavg()[0]]
    while True:
        time.sleep(interval)
        times = np.array(os.times())
        dtimes = times - times_store    # difference since last loop
        usr = dtimes[0]/dtimes[4]       # fraction, 0 - 1
        sys = dtimes[1]/dtimes[4]
        times_store = times
        cpu_usage = [usr, sys, os.getloadavg()[0]]
#///////////////////////////////////////////////////////////////////////////////////////////////////
# Screen setup parameters
if opt.lcd4:                        # setup for directfb (non-X) graphics
    SCREEN_SIZE = (480,272)         # default size for the 4" LCD (480x272)
    SCREEN_MODE = pg.FULLSCREEN
    # If we are root, we can set up LCD4 brightness.
    brightness = str(min(100, max(0, opt.lcd4_brightness)))     # validated string
    # Find path of script (same directory as iq.py) and append brightness value
    cmd = os.path.join( os.path.split(sys.argv[0])[0], "lcd4_brightness.sh") \
        + " %s" % brightness
    # (The subprocess script is a no-op if we are not root.)
    subprocess.call(cmd, shell=True)    # invoke shell script
else:
#///////////////////////////////////////////////////////////////////////////////////////////////////
#///////////////////////////////////////////////////////////////////////////////////////////////////
#(LILLIPUT 1180, 620) 
# OBAVEZNO PROCITATI  Podesiti raspi-config rezoluciju na 1024,768,60
# ili podesavati ispisivanje na ekranu za svaku drugu rezoluciju ekrana
#SCREEN_MODE = pg.FULLSCREEN if opt.fullscreen else 0
#   SCREEN_SIZE = (1000, 740) if opt.waterfall \
#                    else (1000,745) # NB: graphics may not scale well (LILLIPUT (1000, 765)(800,600))
#Speed_WF = opt.speed_wf #How many lines to use in the waterfall 50
#///////////////////////////////////////////////////////////////////////////////////////////////////
# Podesiti raspi-config rezoluciju na 1024,768,60 
   SCREEN_MODE = pg.FULLSCREEN if opt.fullscreen else 0
   SCREEN_SIZE = (1000, 750) if opt.waterfall \
                     else (1000,750) # NB: graphics may not scale well (LILLIPUT (1000, 750)(800,750))
Speed_WF = opt.speed_wf #How many lines to use in the waterfall 50
#///////////////////////////////////////////////////////////////////////////////////////////////////
#///////////////////////////////////////////////////////////////////////////////////////////////////
#(TFT_LCD 320, 240) 
# OBAVEZNO PROCITATI  Podesiti raspi-config rezoluciju na 1024,768,60
# ili podesavati ispisivanje na ekranu za svaku drugu rezoluciju ekrana
#    SCREEN_MODE = pg.FULLSCREEN if opt.fullscreen else 0
#    SCREEN_SIZE = (1000, 740) if opt.waterfall \
#                    else (1000,745) # NB: graphics may not scale well (LILLIPUT (1000, 765)(800,600))
#Speed_WF = opt.speed_wf #How many lines to use in the waterfall 50
#///////////////////////////////////////////////////////////////////////////////////////////////////
#///////////////////////////////////////////////////////////////////////////////////////////////////
# Initialize pygame (pg)
# We should not use pg.init(), because we don't want pg audio functions. 
pg.display.init()
pg.mouse.set_visible(False)
pg.font.init()
#--------------------------------------------------------------------------------------------------
# Define the main window surface
surf_main = pg.display.set_mode(SCREEN_SIZE, SCREEN_MODE)
w_main = surf_main.get_width()
#--------------------------------------------------------------------------------------------------
# derived parameters
w_spectra = w_main-10           # Allow a small margin, left and right -10
w_middle = w_spectra/2          # mid point of spectrum/2
x_spectra = (w_main-w_spectra) / 2.0    # x coord. of spectrum on screen 2.0

h_2d = 2*SCREEN_SIZE[1]/3 if opt.waterfall \
            else SCREEN_SIZE[1]                    # height of 2d spectrum display
h_2d -= 20 # compensate for LCD4 overscan? 20
y_2d = 10. # y position of 2d disp. (screen top = 0)10.
#--------------------------------------------------------------------------------------------------
# NB: transform size must be <= w_spectra.  I.e., need at least one
# pixel of width per data point.  Otherwise, waterfall won't work, etc.
if opt.size > w_spectra:
    print opt.size
    for n in [1024, 512, 256, 128]:
        if n <= w_spectra:
            print "*** Size was reset from %d to %d." % (opt.size, n)
            opt.size = n    # Force size to be 2**k (ok, but may not be best choice) opt.size = n 
            break
#----------------
chunk_size = opt.buffers * opt.size # No. samples per chunk (pyaudio callback)
chunk_time = float(chunk_size) / opt.sample_rate
#--------------------------------------------------------------------------------------------------
# Initialize input mode, RTL or AF
if opt.source=="rtl":             # input from RTL dongle
    import iq_rtl as rtl
    dataIn = rtl.RTL_In(opt)
    gainsteps = opt.rtl_gain
    samplesteps = opt.sample_rate
elif opt.source=='audio':         # input from audio card
    import iq_af as af
    dataIn = af.DataInput(opt)
else:
    print "unrecognized mode"
    quit_all()
#--------------------------------------------------------------------------------------------------
myDSP = dsp.DSP(opt)            # Establish DSP logic
#--------------------------------------------------------------------------------------------------
# Surface for the 2d spectrum
surf_2d = pg.Surface((w_spectra, h_2d))             # Initialized to black
surf_2d_graticule = pg.Surface((w_spectra, h_2d))   # to hold fixed graticule
#--------------------------------------------------------------------------------------------------
# define two LED widgets
led_urun = LED(10)
led_clip = LED(10)
#--------------------------------------------------------------------------------------------------
# Waterfall geometry
h_wf = SCREEN_SIZE[1]/3             # Height of waterfall (3d spectrum)3
y_wf = y_2d + h_2d              # Position just below 2d surface
#--------------------------------------------------------------------------------------------------
# Surface for waterfall (3d) spectrum
surf_wf = pg.Surface((w_spectra, h_wf))
pg.display.set_caption(opt.ident)     # Title for main window
# Establish fonts for screen text.
lgfont = pg.font.SysFont('sans', 48)#16
lgfont_ht = lgfont.get_linesize()   # text height
medfont = pg.font.SysFont('sans', 26)#12
medfont_ht = medfont.get_linesize()
smfont = pg.font.SysFont('mono', 32)#9
smfont_ht = smfont.get_linesize()
# Define the size of a unit pixel in the waterfall
wf_pixel_size = (w_spectra/opt.size, h_wf/Speed_WF)
# min, max dB for wf palette
v_min = opt.v_min    # lower end (-120dB)
v_max = opt.v_max    # higher end (-20dB)
nsteps = opt.nsteps  # number of distinct colors 50
#--------------------------------------------------------------------------------------------------
if opt.waterfall:
    # Instantiate the waterfall and palette data
    mywf = wf.Wf(opt, v_min, v_max, nsteps, wf_pixel_size)
#--------------------------------------------------------------------------------------------------
if opt.hamlib:
    import Hamlib
    # start up Hamlib rig connection
    Hamlib.rig_set_debug (Hamlib.RIG_DEBUG_NONE)
    rig = Hamlib.Rig(opt.hamlib_rigtype)
    rig.set_conf ("rig_pathname",opt.hamlib_device)
    rig.set_conf ("retry","5")
    rig.open ()
    # Create thread for Hamlib freq. checking.  
    # Helps to even out the loop timing, maybe.
    hl_thread = threading.Thread(target=updatefreq, args = (opt.hamlib_interval, rig))
    hl_thread.daemon = True
    hl_thread.start()
    print "Hamlib thread started."
else:
    print "Hamlib not requested."
#--------------------------------------------------------------------------------------------------
# Create thread for cpu load monitor
lm_thread = threading.Thread(target=cpu_load, args = (opt.cpu_load_interval,))
lm_thread.daemon = True
lm_thread.start()
print "CPU monitor thread started."
#--------------------------------------------------------------------------------------------------
# Create graticule providing 2d graph calibration.
mygraticule = Graticule(opt, smfont, h_2d, w_spectra, GRAT_COLOR, GRAT_COLOR_2)
#sp_min, sp_max  =  sp_min_def, sp_max_def  =  -120, -20
sp_min, sp_max  =  sp_min_def, sp_max_def  =  opt.sp_min, opt.sp_max
mygraticule.set_range(sp_min, sp_max)
surf_2d_graticule = mygraticule.make()
#--------------------------------------------------------------------------------------------------
# ** MAIN PROGRAM LOOP **
run_flag = True                 # set false to suspend for help screen etc.
info_phase = 2                  # > 0 --> show info overlay
info_counter = 0
tloop = 0.
t_last_data = 0.
nframe = 0
t_frame0 = time.time()
led_overflow_ct = 0
print "Update interval = %.2f ms" % float(1000*chunk_time)
#////////////////////////////////////////////////////////////////////////////////////
global FlipStep, shifted_levo_desno, DcFilter, rtl_frequency		
FlipStep = 0
shifted_levo_desno = 0
DcFilter = False
rtl_frequency = opt.rtl_frequency	
savbrtest = 0
#-------------------------------------------------------------------------------------
def SaveIniData():
    global savbrtest
    SpMin = sp_min
    SpMax = sp_max
    RtlGain = gainsteps
    RtlFrequency = dataIn.rtl.get_center_freq() 
    NSteps = nsteps
    SpeedWF = Speed_WF
    VMin = v_min
    VMax = v_max
    txt_file = open('/home/pi/IQ_SHOW_ICOM_LILLIPUT_OR_320X240/ConfigAll.py', 'w')
    txt_file.write('SpMin = ' + format(SpMin) + '\n')
    txt_file.write('SpMax = ' + format(SpMax) + '\n') 
    txt_file.write('RtlGain = ' + format(RtlGain) + '\n')
    txt_file.write('RtlFrequency = ' + format(RtlFrequency) + '\n')			
    txt_file.write('NSteps = ' + format(NSteps) + '\n')
    txt_file.write('SpeedWF = ' + format(SpeedWF) + '\n')	
    txt_file.write('VMin = ' + format(VMin) + '\n')
    txt_file.write('VMax= '+ format(VMax) + '\n')
    txt_file.close()
    # Kontrola prikaza sta je shranjeno
    print "-----------------------------------------"	
    print "sp_min: ", SpMin
    print "sp_max: ", SpMax
    print "rtl_gain: ", RtlGain
    print "rtl_frequency: ", RtlFrequency
    print "nsteps: ", NSteps
    print "v_min: ", VMin
    print "v_max: ", VMax
    savbrtest += 1
    print "SAVE AS #", savbrtest 
#-------------------------------------------------------------------------------------					
while True:
    wf_pixel_size = (w_spectra/opt.size, h_wf/Speed_WF)
    mywf = wf.Wf(opt, v_min, v_max, nsteps, wf_pixel_size)
    nframe += 1                 # keep track of loops for possible bookkeeping
    # Each time through the main loop, we reconstruct the main screen
    #-------------------
    surf_main.fill(NEW_BGCOLOR) # Erase with background color
	#-------------------
    # Each time through this loop, we receive an audio chunk, containing
    # multiple buffers.  The buffers have been transformed and the log power
    # spectra from each buffer will be provided in sp_log, which will be
    # plotted in the "2d" graph area.  After a number of log spectra are
    # displayed in the "2d" graph, a new line of the waterfall is generated.
    #surf_main.blit(top_matter, (10,10))     # static operating info
#-----------------------------------------------------------------------------------
    # Line of text with receiver center freq. if available
    if opt.hamlib:
        msg = "%.3f kHz" % rigfreq   # take current rigfreq from hamlib thread
    elif opt.source=='rtl':
        msg = "%.3f MHz" % (dataIn.rtl.get_center_freq()/1.e6)
    if opt.hamlib or (opt.source=='rtl'):
        # Center it and blit just above 2d display
        ww, hh = lgfont.size(msg)
        #surf_main.blit(lgfont.render(msg, 1, BLACK, NEW_BGCOLOR),(w_middle + x_spectra - ww/2, y_2d-hh))
        #surf_main.blit(lgfont.render(msg, 1, BLACK, NEW_BGCOLOR),(w_middle + x_spectra - ww/2, y_2d))		
    # show overflow & underrun indicators (for audio, not rtl)
    if opt.source=='audio':
        if af.led_underrun_ct > 0:        # underflow flag in af module
            sled = led_urun.get_LED_surface(RED)
            af.led_underrun_ct -= 1        # count down to extinguish
        else:
            sled = led_urun.get_LED_surface(None)   #off!
        msg = "Buffer underrun"
        ww, hh = medfont.size(msg)
        ww1 = SCREEN_SIZE[0]-ww-10
        surf_main.blit(medfont.render(msg, 1, BLACK, NEW_BGCOLOR), (ww1, y_2d-hh))
        surf_main.blit(sled, (ww1-15, y_2d-hh))
        if myDSP.led_clip_ct > 0:                   # overflow flag
            sled = led_clip.get_LED_surface(RED)
            myDSP.led_clip_ct -= 1
        else:
            sled = led_clip.get_LED_surface(None)   #off!
        msg = "Pulse clip"
        ww, hh = medfont.size(msg)
        surf_main.blit(medfont.render(msg, 1, BLACK, NEW_BGCOLOR), (25, y_2d-hh))
        surf_main.blit(sled, (10, y_2d-hh))	
#-----------------------------------------------------------------------------------
    if opt.source=='rtl':               # Input from RTL-SDR dongle
        iq_data_cmplx = dataIn.ReadSamples(chunk_size)	   		
        if opt.rev_iq:                  # reverse spectrum?
            iq_data_cmplx = np.imag(iq_data_cmplx)+1j*np.real(iq_data_cmplx)
        time.sleep(0.05)                # slow down if fast PC
        stats = [ 0, 0]                 # for now...
    else:                               # Input from audio card
        # In its separate thread, a chunk of audio data has accumulated.
        # When ready, pull log power spectrum data out of queue.
        while dataIn.dataqueue.qsize() < 2:
            time.sleep(0.1 * chunk_time )
        my_in_data_s = dataIn.dataqueue.get(True, 2.0)  # block w/timeout
        dataIn.dataqueue.task_done()
        # Convert string of 16-bit I,Q samples to complex floating
        iq_local = np.fromstring(my_in_data_s,dtype=np.int16).astype('float32')
        re_d = np.array(iq_local[1::2])                      # right input (I)
        im_d = np.array(iq_local[0::2])                      # left  input (Q)
        # The PCM290x chip has 1 lag offset of R wrt L channel. Fix, if needed.
        if opt.lagfix:
            im_d = np.roll(im_d, 1)
        # Get some stats (max values) to monitor gain settings, etc.
        stats = [int(np.amax(re_d)), int(np.amax(im_d))]
        iq_data_cmplx = np.array(re_d + im_d*1j)
#-----------------------------------------------------------------------------------			
    sp_log = myDSP.GetLogPowerSpectrum(iq_data_cmplx)
    zoom_log = myDSP.GetLogPowerSpectrum(iq_data_cmplx)
#-----------------------------------------------------------------------------------	
    # filter za dc signal vertikalna linija sredine skale   
    if DcFilter == True:
        ren_br = 3    	
        sp_xL = zoom_log[(len(zoom_log)/2)-ren_br]
        sp_xD = zoom_log[(len(zoom_log)/2)+ren_br]	
        #for br in range(ren_br): 
        #	zoom_log[(len(zoom_log)/2)-br+(ren_br/2)] = sp_x
        zoom_log[(len(zoom_log)/2)+0+(ren_br/2)] = sp_xL + 0		
        zoom_log[(len(zoom_log)/2)-1+(ren_br/2)] = sp_xD + 2
        zoom_log[(len(zoom_log)/2)-2+(ren_br/2)] = sp_xL + 1  			
#-----------------------------------------------------------------------------------	
    # ZOOM faktor prikaza x*1
    loset = 181
    if ZoomScrin == 1:
    	lenBr = len(sp_log)
    	for br in range(lenBr):
			sp_log[br] = -loset
    	for br in range(128,lenBr-128):
			sp_log[br-128] = zoom_log[br]
    	for br in range(lenBr):
			zoom_log[br] = -loset		
		#-----------------------		
    	for br in range(lenBr/2):
    		brx = br*2
    		zoom_log[brx] = sp_log[br]
    		zoom_log[brx+1] = sp_log[br]
#-----------------------
    # ZOOM faktor prikaza x*2
    if ZoomScrin == 2:
    	for loopbr in range(2):
    		lenBr = len(sp_log)
    		for br in range(lenBr):
    			sp_log[br] = -loset
    		for br in range(128,lenBr-128):
    			sp_log[br-128] = zoom_log[br]
    		for br in range(lenBr):
    			zoom_log[br] = -loset		
    		#-----------------------		
    		for br in range(lenBr/2):
    			brx = br*2
    			zoom_log[brx] = sp_log[br]
    			zoom_log[brx+1] = sp_log[br]
#-----------------------
    # ZOOM faktor prikaza x*3
    if ZoomScrin == 3:
    	for loopbr in range(3):
    		lenBr = len(sp_log)
    		for br in range(lenBr):
    			sp_log[br] = -loset
    		for br in range(128,lenBr-128):
    			sp_log[br-128] = zoom_log[br]
    		for br in range(lenBr):
    			zoom_log[br] = -loset		
    		#-----------------------		
    		for br in range(lenBr/2):
    			brx = br*2
    			zoom_log[brx] = sp_log[br]
    			zoom_log[brx+1] = sp_log[br]
#-----------------------------------------------------------------------------------			
    sp_log = zoom_log
#-----------------------------------------------------------------------------------
    if opt.source=='rtl': # Boost rtl spectrum (arbitrary amount)
        sp_log += 60    # RTL data were normalized to +/- 50.
    yscale = float(h_2d)/(sp_max-sp_min)    # yscale is screen units per dB
    # Set the 2d surface to background/graticule.
#--------------------
    surf_2d.blit(surf_2d_graticule, (0, 0))
#--------------------	
    # Draw the "2d" spectrum graph
    #sp_scaled = ((sp_log - sp_min) * yscale) + 3.
    sp_scaled = ((sp_log - sp_min) * yscale) + 3.
    ylist = list(sp_scaled)
    ylist = [ h_2d - x for x in ylist ]                 # flip the y's
    lylist = len(ylist)
    xlist = [ x* w_spectra/lylist for x in xrange(lylist)]
#-----------------------------------------------------------------------------------
    # Draw the spectrum based on our data lists.
    #pg.draw.lines(surf_2d, YELLOWNEW, False, zip(xlist,ylist), 1)# Orginalni prikaz
    NEWCOLOR = (20, 100, 20)	
    pg.draw.lines(surf_2d, NEWCOLOR, False, zip(xlist,ylist), 1)# Orginalni prikaz
#-----------------------------------------------------------------------------------
    # Draw line segments to edit by S59KB
    #ylast = ylist[0]
    #for br in range(len(ylist)):
    #	x_poz = (br * 1.9222) #1.9222 prilagodjeno za ovu rezoluciju
    #	y= ylist[br]+100
    #	pg.draw.line(surf_2d, PeakEfect(y), (x_poz, ylast), (x_poz, y),4)		
    #	pg.draw.line(surf_2d, ColorEfect(y), (x_poz+2, y), (x_poz+2, 435),2)#435 je pozicija od sredine na gore
    #	ylast = y
#-----------------------------------------------------------------------------------		
    # Draw line segments to edit by S59KB
    VerLine = 1
    ylast = ylist[0]
    for br in range(len(ylist)):
    	x_poz = (br * 1.9222) #1.9222 prilagodjeno za ovu rezoluciju
    	y= ylist[br]+100
    	pg.draw.line(surf_2d, PeakEfect(y), (x_poz, ylast), (x_poz, y),4)		
    	pg.draw.line(surf_2d, ColorEfect(y), (x_poz+2, y), (x_poz+2, 435),VerLine)#435 je pozicija od sredine na gore
    	ylast = y
#-----------------------------------------------------------------------------------
    # Render Signal plus to Noise of Ceneter Frequency in center top.	
    # Prikaz signala u s jedinicama i dB
    set_sig = (ylist[(len(ylist))/2]+5)
    set_sig = (360 -  set_sig)
    #print set_sig
    #----------
    y_sig = 35 
    x_sig_lo = 300 
    x_sig_hi = 250 
    x_lo_hi = 385
    #----------
    pg.draw.line(surf_2d, YELLOWNEW,(x_sig_lo, y_sig+1), (x_sig_lo+x_lo_hi, y_sig+1),3)
    for i in range(4,18):
        pg.draw.line(surf_2d, NEWCOLOR, (x_sig_lo, y_sig+i), (x_sig_lo+x_lo_hi, y_sig+i))
    pg.draw.line(surf_2d, YELLOWNEW,(x_sig_lo, y_sig+18), (x_sig_lo+x_lo_hi, y_sig+18),3)
    s_units_br = format(set_sig)
    if set_sig > 0:
    	for i in range(3,17):
    		if set_sig < (x_sig_hi+100):
    			pg.draw.line(surf_2d, YELLOWNEW, (x_sig_lo, y_sig+i), (x_sig_lo+set_sig, y_sig+i))		
    			if set_sig > x_sig_hi:
    				pg.draw.line(surf_2d, RED, (x_sig_lo+x_sig_hi, y_sig+i), (x_sig_lo+set_sig, y_sig+i))
    		else:
    			pg.draw.line(surf_2d, DARK_RED, (x_sig_lo, y_sig+i), (x_sig_lo+x_lo_hi, y_sig+i))
#-----------------------------------------------------------------------------------
    # Place 2d spectrum on main surface
    surf_main.blit(surf_2d, (x_spectra, y_2d))
#-----------------------------------------------------------------------------------
    if opt.waterfall:
        # Calculate the new Waterfall line and blit it to main surface
        nsum = opt.waterfall_accumulation    # 2d spectra per wf line
        mywf.calculate(sp_log, nsum, surf_wf)
        surf_main.blit(surf_wf, (x_spectra, y_wf-2))		
#-----------------------------------------------------------------------------------
    if info_phase > 0:
        # Assemble and show semi-transparent overlay info screen
        # This takes cpu time, so don't recompute it too often. (DSP & graphics
        # are still running.)
        info_counter = ( info_counter + 1 ) % INFO_CYCLE
        if info_counter == 1:           # First time through, and every INFO_CYCLE-th time thereafter.
            # Some button labels to show at right of LCD4 window
            # Add labels for LCD4 buttons.
            place_buttons = False
            if opt.lcd4 or (w_main==480):
                place_buttons = True
                button_names = [ " LT", " RT ", " UP", " DN", "ENT" ]
                button_vloc = [ 20, 70, 120, 170, 220 ]
                button_surfs = []
                for bb in button_names:
                    button_surfs.append(medfont.render(bb, 1, WHITE, BLACK))
            # Help info will be placed toward top of window.
            # Info comes in 2 phases (0 - 2), cycle among them with <return>   #K_LEFT K_RIGHT K_RETURN K_UP K_DOWN        				
            if info_phase == 1:
                lines = [ " KEYBOARD CONTROLS: ",
                          " - Change forward: (K_RIGHT) ",
						  " - Change back: (K_LEFT) ",
                          " - Change upper plot dB limit: (K_UP) inc; (K_DOWN)dec  ",
                          " - Change lower plot dB limit: (K_UP)inc; (K_DOWN)dec  ",
                          " - Change Gain dB: (K_UP)inc; (K_DOWN)dec  ",
                          " - Change Rig 1 kHz: (K_UP)inc; (K_DOWN)dec  ",						  
                          " - Change WF palette upper limit: (K_UP)inc; (K_DOWN)dec  ",
                          " - Change WF palette lower limit: (K_UP)inc; (K_DOWN)dec  ",
						  " - Change next display: (K_RIGHT) and (K_LEFT)  "]				  
            elif info_phase == 2:
                lines = [ ""]
            else:
                lines = [ "Invalid info phase!"]    # we should never arrive here.
                info_phase = 0
            #-------------------------------------------------------------------------------------------------------------------------	
            wh = (0, 0)
            for il in lines:                # Find max line width, height
                wh = map(max, wh, medfont.size(il))
            #help_matter = pg.Surface((wh[0]+24, len(lines)*wh[1]+15) )#, flags=pg.SRCALPHA)
            help_matter = pg.Surface((wh[0]+0, len(lines)*wh[1]+25) )#, flags=pg.SRCALPHA)
            for ix,x in enumerate(lines):
                help_matter.blit(medfont.render(x, 1, TCOLOR2), (5,ix*wh[1]+15))#(20,ix*wh[1]+15)		
			#-------------------------------------------------------------------------------------------------------------------------
			# Pre-formatx "static" text items to save time in real-time loop
			# Useful operating parameters
            #parms_msg = "Fs = %d Hz; Res. = %.1f Hz;" " chans = %d; width = %d px; acc = %.3f sec" % \
            #	(opt.sample_rate, float(opt.sample_rate)/opt.size, opt.size, w_spectra, float(opt.size*opt.buffers)/opt.sample_rate)
            #wparms, hparms = medfont.size(parms_msg)
            #parms_matter = pg.Surface((wparms, hparms) )#, flags=pg.SRCALPHA)
            #parms_matter.blit(medfont.render(parms_msg, 1, TCOLOR2), (50,50))#(0,0)
			#-------------------------------------------------------------------------------------------------------------------------		
            # "Live" info is placed toward bottom of window...
            # Width of this surface is a guess. (It should be computed.)
            #live_surface = pg.Surface((1000,48), 0)#(430,48)
            # give live sp_min, sp_max, v_min, v_max
            #msg = "dB scale min= %d, max= %d" % (sp_min, sp_max)
            #live_surface.blit(medfont.render(msg, 1, TCOLOR2), (0,0))#(10,0)
            #---------------------------------------------------------------------------  
            #Podaci za prikaz max/min tipki F1 do F8
            live_surface = pg.Surface((990,32), 0)#(990,32)
            scalafont = pg.font.SysFont('sans', 60)
            live_surface.blit(scalafont.render("________________________________", 1, NEW_BGCOLOR),(0, -62))#(0, -62)			
            #---------------------------------------------------------------
            TCOLORON = ( 255, 255, 255)
            msglevi1  = "Smin: %d" % (sp_min)
            msglevi2  = "Smax: %d" % (sp_max)
            Gain_txt = format(gainsteps*2)
            shifted_txt = format(shifted_levo_desno)			
            nsteps_txt = format(nsteps)
            SpeedWF_txt = format(Speed_WF)			
            msgdesni1 = "Wmin: %d" % (v_min)			
            msgdesni2 = "Wmax: %d" % (v_max)
            NEWCOLOR =  (250, 250, 50)
            infofont = pg.font.SysFont('sans', 22)#22
            if Gain_txt == "100":
                Gain_txt = "Auto"
            if FlipStep == 1:
                live_surface.blit(infofont.render(msglevi1, 1, NEWCOLOR), (10,5))
            else:
                live_surface.blit(infofont.render(msglevi1, 1, TCOLORON), (10,5))
            if FlipStep == 2:
                live_surface.blit(infofont.render(msglevi2, 1, NEWCOLOR), (140,5))			
            else:
                live_surface.blit(infofont.render(msglevi2, 1, TCOLORON), (140,5))			
            if FlipStep == 3:
                live_surface.blit(infofont.render("Gain: " + Gain_txt, 1, NEWCOLOR), (260,5))
            else:				
                live_surface.blit(infofont.render("Gain: " + Gain_txt, 1, TCOLORON), (260,5))            
            if FlipStep == 4:
                live_surface.blit(infofont.render("Rig: " + shifted_txt, 1, NEWCOLOR), (385,5))
            else:				
                live_surface.blit(infofont.render("Rig: " + shifted_txt, 1, TCOLORON), (385,5))            
            if FlipStep == 5:
                live_surface.blit(infofont.render("Nstep: " + nsteps_txt, 1, NEWCOLOR), (470,5))
            else:				
                live_surface.blit(infofont.render("Nstep: " + nsteps_txt, 1, TCOLORON), (470,5))            
            if FlipStep == 6:
                live_surface.blit(infofont.render("Speed: " + SpeedWF_txt, 1, NEWCOLOR), (590,5))
            else:				
                live_surface.blit(infofont.render("Speed: " + SpeedWF_txt, 1, TCOLORON), (590,5))             
            if FlipStep == 7:
                live_surface.blit(infofont.render(msgdesni1, 1, NEWCOLOR), (725,5))			
            else:
                live_surface.blit(infofont.render(msgdesni1, 1, TCOLORON), (725,5))			
            if FlipStep == 8:
                live_surface.blit(infofont.render(msgdesni2, 1, NEWCOLOR), (860,5))			
            else:
                live_surface.blit(infofont.render(msgdesni2, 1, TCOLORON), (860,5))
            #---------------------------------------------------------------------------				
            """infofont = pg.font.SysFont('sans', 40)#22	
            live_surface.blit(infofont.render("|", 1, TCOLORON), (120,-5))
            live_surface.blit(infofont.render("|", 1, TCOLORON), (250,-5))
            live_surface.blit(infofont.render("|", 1, TCOLORON), (360,-5))
            live_surface.blit(infofont.render("|", 1, TCOLORON), (450,-5))
            live_surface.blit(infofont.render("|", 1, TCOLORON), (570,-5))
            live_surface.blit(infofont.render("|", 1, TCOLORON), (705,-5))
            live_surface.blit(infofont.render("|", 1, TCOLORON), (840,-5))"""			
            #---------------------------------------------------------------------------
            #if opt.waterfall:
                # Palette adjustments info
                #msg = "WF palette min= %d, max= %d" % (v_min, v_max)
                #live_surface.blit(medfont.render(msg, 1, TCOLOR2), (400, 0))#(200, 0)
            #live_surface.blit(parms_matter, (10,16))
            #---------------------------------------------------------------------------
            #if opt.source=='audio':
                #msg = "ADC max I:%05d; Q:%05d" % (stats[0], stats[1])
                #live_surface.blit(medfont.render(msg, 1, TCOLOR2), (10, 32))#(10, 32)
            # Show the live cpu load information from cpu_usage thread.
            #msg = "Load usr=%3.2f; sys=%3.2f; load avg=%.2f" % \
            #    (cpu_usage[0], cpu_usage[1], cpu_usage[2])
            #live_surface.blit(medfont.render(msg, 1, TCOLOR2), (200, 64))#(200, 64)
        #--------------------------------------------------------------------------------			
        # Blit newly formatted -- or old -- screen to main surface.
        #if place_buttons:   # Do we have rt hand buttons to place?
            #for ix, bb in enumerate(button_surfs):
                #surf_main.blit(bb, (449, button_vloc[ix]))
        surf_main.blit(help_matter, (50,20))# podesavanje help text)(50,20)	
        surf_main.blit(live_surface,(5,SCREEN_SIZE[1]-35)) # podesavanje zadnje vrsnice (SCREEN_SIZE[1]-35)		
#--------------------------------------------------------------------------------	
    # Check for pygame events - keyboard, etc.	
	for event in pg.event.get():	
		if event.type == pg.QUIT:
			quit_all()
		elif event.type == pg.KEYDOWN:
			shifted = event.mod & (pg.KMOD_LSHIFT | pg.KMOD_RSHIFT)		
			if event.key == pg.K_LEFT:
				FlipStep -=1
				if FlipStep < 0:
					FlipStep = 8
				SaveIniData()
			if event.key == pg.K_RIGHT:
				FlipStep +=1
				if FlipStep > 8:
					FlipStep = 0
				SaveIniData()
			if event.key == pg.K_RETURN:
				info_phase += 1      # Jump to phase 
				if info_phase > 2:
					info_phase = 1
					info_counter = 0     #   (next time)
			#--------------------------------------------
			if FlipStep == 0:
				if event.key == pg.K_UP:
					ZoomScrin += 1
					if ZoomScrin > 3:
						ZoomScrin = 0
					surf_2d_graticule = mygraticule.make()
				if event.key == pg.K_DOWN:
					DcFilter = not DcFilter					
			if FlipStep == 2:
				if event.key == pg.K_UP:
					if sp_max < 0:
						sp_max += 5
					mygraticule.set_range(sp_min, sp_max)
					surf_2d_graticule = mygraticule.make()
				if event.key == pg.K_DOWN:
					if sp_max > -180 and sp_max > sp_min + 5:
						sp_max -= 5
					mygraticule.set_range(sp_min, sp_max)
					surf_2d_graticule = mygraticule.make()				
			if FlipStep == 1:		
				if event.key == pg.K_UP:
					if sp_min < sp_max -5:
						sp_min += 5
					mygraticule.set_range(sp_min, sp_max)
					surf_2d_graticule = mygraticule.make()
				if event.key == pg.K_DOWN:
					if sp_min > -180:
						sp_min -= 5
					mygraticule.set_range(sp_min, sp_max)
					surf_2d_graticule = mygraticule.make()
			if FlipStep == 3:		
				if event.key == pg.K_UP:
					gainsteps += 5
					if gainsteps > 50:
						gainsteps = 50					
					dataIn.SetGain(gainsteps)
				if event.key == pg.K_DOWN:
					gainsteps -= 5
					if gainsteps < 5:
						gainsteps = 5
					dataIn.SetGain(gainsteps)
			if FlipStep == 4:			
				if event.key == pg.K_UP:
					finc = 0.1e3 if shifted else 1e3			
					dataIn.rtl.center_freq = dataIn.rtl.get_center_freq()+finc
					shifted_levo_desno = shifted_levo_desno + 1				
				if event.key == pg.K_DOWN:
					finc = -0.1e3 if shifted else -1e3				
					dataIn.rtl.center_freq = dataIn.rtl.get_center_freq()+finc
					shifted_levo_desno = shifted_levo_desno - 1	
			if FlipStep == 5:		
				if event.key == pg.K_UP:
					nsteps += 1
					if nsteps > 50 :
						nsteps = 50					
				if event.key == pg.K_DOWN:
					nsteps -= 1	
					if nsteps < 3 :
						nsteps = 3
			if FlipStep == 6:		
				if event.key == pg.K_UP:
					Speed_WF += 10
					if Speed_WF > 200 :
						Speed_WF = 200					
				if event.key == pg.K_DOWN:
					Speed_WF -= 10	
					if Speed_WF < 10 :
						Speed_WF = 10						
			if FlipStep == 8:
				if event.key == pg.K_UP:
					if v_max < 0:
						v_max += 5
					mywf.set_range(v_min,v_max)
				if event.key == pg.K_DOWN:
					if v_max > v_min + 5:
						v_max -= 5
					mywf.set_range(v_min,v_max)				
			if FlipStep == 7:		
				if event.key == pg.K_UP:
					if v_min < v_max - 5:
						v_min += 5
					mywf.set_range(v_min,v_max)
				if event.key == pg.K_DOWN:
					if v_min > -180:
						v_min -= 5
					mywf.set_range(v_min,v_max)
#-----------------------------------------------------------------
	if GPIO.input(SetButton) == 0:
		FlipStep +=1
		if FlipStep > 8:
			FlipStep = 0
		SaveIniData()
		time.sleep(0.1)
	#---------
	if FlipStep == 0:
		if GPIO.input(UpButton) == 0:
			ZoomScrin += 1
			if ZoomScrin > 3:
				ZoomScrin = 0
			surf_2d_graticule = mygraticule.make()			
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			DcFilter = not DcFilter
			time.sleep(0.1)
	if FlipStep == 2:
		if GPIO.input(UpButton) == 0:
			if sp_max < 0:
				sp_max += 5
			mygraticule.set_range(sp_min, sp_max)
			surf_2d_graticule = mygraticule.make()
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			if sp_max > -180 and sp_max > sp_min + 5:
				sp_max -= 5
			mygraticule.set_range(sp_min, sp_max)
			surf_2d_graticule = mygraticule.make()
			time.sleep(0.1)				
	if FlipStep == 1:		
		if GPIO.input(UpButton) == 0:
			if sp_min < sp_max -5:
				sp_min += 5
			mygraticule.set_range(sp_min, sp_max)
			surf_2d_graticule = mygraticule.make()
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			if sp_min > -180:
				sp_min -= 5
			mygraticule.set_range(sp_min, sp_max)
			surf_2d_graticule = mygraticule.make()
			time.sleep(0.1)		
	if FlipStep == 3:		
		if GPIO.input(UpButton) == 0:
			gainsteps += 5
			if gainsteps > 50:
				gainsteps = 50
			dataIn.SetGain(gainsteps)
			time.sleep(0.1)	
		if GPIO.input(DnButton) == 0:
			gainsteps -= 5
			if gainsteps < 5:
				gainsteps = 5
			dataIn.SetGain(gainsteps)								
			time.sleep(0.1)									
	if FlipStep == 4:	
		if GPIO.input(UpButton) == 0:
			#finc = 0.1e3 if shifted else 1e3			
			shifted_levo_desno = shifted_levo_desno + 1			
			dataIn.rtl.center_freq = dataIn.rtl.get_center_freq()+(1000)
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			#finc = -0.1e3 if shifted else -1e3	
			shifted_levo_desno = shifted_levo_desno - 1			
			dataIn.rtl.center_freq = dataIn.rtl.get_center_freq()-(1000)
			time.sleep(0.1)
	if FlipStep == 5:	
		if GPIO.input(UpButton) == 0:
			nsteps += 1
			if nsteps > 50 :
				nsteps = 50
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			nsteps -= 1	
			if nsteps < 3 :
				nsteps = 3
			time.sleep(0.1)
	if FlipStep == 6:	
		if GPIO.input(UpButton) == 0:
			Speed_WF += 10
			if Speed_WF > 200 :
				Speed_WF = 200
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			Speed_WF -= 10	
			if Speed_WF < 10 :
				Speed_WF = 10
			time.sleep(0.1)			
	if FlipStep == 8:
		if GPIO.input(UpButton) == 0:
			if v_max < 0:
				v_max += 5
			mywf.set_range(v_min,v_max)
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			if v_max > v_min + 5:
				v_max -= 5
			mywf.set_range(v_min,v_max)
			time.sleep(0.1)				
	if FlipStep == 7:		
		if GPIO.input(UpButton) == 0:
			if v_min < v_max - 5:
				v_min += 5
			mywf.set_range(v_min,v_max)
			time.sleep(0.1)
		if GPIO.input(DnButton) == 0:
			if v_min > -180:
				v_min -= 5
			mywf.set_range(v_min,v_max)
			time.sleep(0.1)
#-------------------------------------------------------------     
	# Finally, update display for user
	pg.display.update()
	# End of main loop	
	# DODATO ZA DIREKTNO PODESAVANJE spectrum / waterfall 
#---------------------------------------------------------------------------------		
# END OF IQ.PY
