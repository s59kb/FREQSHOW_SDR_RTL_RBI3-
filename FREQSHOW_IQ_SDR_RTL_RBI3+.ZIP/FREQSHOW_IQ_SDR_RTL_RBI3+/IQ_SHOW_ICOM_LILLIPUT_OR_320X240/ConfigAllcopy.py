SpMin = -150
SpMax = -40
RtlGain = 25
RtlFrequency = 69006000.0
NSteps = 22
VMin = -120
VMax= -40
