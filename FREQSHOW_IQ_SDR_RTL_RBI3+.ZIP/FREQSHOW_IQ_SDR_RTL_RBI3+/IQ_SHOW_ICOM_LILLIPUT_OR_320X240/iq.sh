#!/bin/bash

# start iq on bbb with sb1240

nice -20 /home/martin/iq/iq.py -i 1 --hamlib -z 256 -b 14 --waterfall

