    for event in pg.event.get():
        if event.type == pg.QUIT:
            quit_all()
        elif event.type == pg.KEYDOWN:
			#--------------------------------------------------------------------------------
            #if info_phase <= 1:         # operacija da se preskoci 1
            #    if event.key == pg.K_F10:#elif event.key == pg.K_RETURN:
            #        info_phase += 1                  # Jump to phase 0 or phase 2 overlay
            #        info_counter = 0	
            #-----------------------------------------------------------------------------
            if info_phase <= 1:         # Normal operation (0) or help phase 1 (1)
                # We usually want left or right shift treated the same!
                shifted = event.mod & (pg.KMOD_LSHIFT | pg.KMOD_RSHIFT)
                if event.key == pg.K_q:
                    quit_all()
                elif event.key == pg.K_u:#            # 'u' or 'U' - chg upper dB
                    if shifted:                         # 'U' move up
                        if sp_max < 0:
                            sp_max += 5
                    else:                               # 'u' move dn
                        if sp_max > -130 and sp_max > sp_min + 10:
                            sp_max -= 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()
                elif event.key == pg.K_l:#            # 'l' or 'L' - chg lower dB
                    if shifted:                         # 'L' move up lower dB
                        if sp_min < sp_max -10:
                            sp_min += 5
                    else:                               # 'l' move down lower dB
                        if sp_min > -140:
                            sp_min -= 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_b:#            # 'b' or 'B' - chg upper pal.
                    if shifted:
                        if v_max < -10:
                            v_max += 5
                    else:
                        if v_max > v_min + 20:
                            v_max -= 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_d:#            # 'd' or 'D' - chg lower pal.
                    if shifted:
                        if v_min < v_max - 20:
                            v_min += 5
                    else:
                        if v_min > -130:
                            v_min -= 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_r:#            # 'r' or 'R' = reset levels
                    sp_min, sp_max = sp_min_def, sp_max_def
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()
                    if opt.waterfall:
                        v_min, v_max = mywf.reset_range()
                # Note that LCD peripheral buttons are Right, Left, Up, Down arrows
                # and "Enter".  (Same as keyboard buttons)
                elif event.key == pg.K_RIGHT or event.key == pg.K_F1:#        # right arrow + freq--------------------------------
                    if opt.source=='rtl':
                        OBRISATI = 0
                        #finc = 10e3 if shifted else 1e3
                        #dataIn.rtl.center_freq = dataIn.rtl.get_center_freq()+finc
                    else:       # audio mode
                        if opt.hamlib:
                            finc = 1.0 if shifted else 0.1
                            rigfreq_request = rigfreq + finc
                        else:
                            print "Rt arrow ignored, no Hamlib"
                elif event.key == pg.K_LEFT or event.key == pg.K_F2:         # left arrow - freq--------------------------------
                    if opt.source=='rtl':
                        OBRISATI = 0
                        #finc = -10e3 if shifted else -1e3
                        #dataIn.rtl.center_freq = dataIn.rtl.get_center_freq()+finc
                    else:       # audio mode
                        if opt.hamlib:
                            finc = -1.0 if shifted else -0.1
                            rigfreq_request = rigfreq + finc
                        else:
                            print "Lt arrow ignored, no Hamlib"
                elif event.key == pg.K_UP:#
                    print "Up"
                elif event.key == pg.K_DOWN:#
                    print "Down"  
                elif event.key == pg.K_F10 or event.key == pg.K_RETURN:#elif event.key == pg.K_RETURN:
                    info_phase += 1                 # Jump to phase 1 or phase 2 overlay
                    info_counter = 0                #   (next time)
            #-----------------------------------------------------------------------------
            elif info_phase == 2:                   # Listen for info phase 2 keys
                if event.key == pg.K_UP or event.key == pg.K_F4:
                    if sp_max < 0:
                        sp_max += 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_DOWN or event.key == pg.K_F3:
                    if sp_max > -140 and sp_max > sp_min + 5:
                        sp_max -= 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_RIGHT or event.key == pg.K_F2:
                    if sp_min < sp_max -5:
                        sp_min += 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_LEFT or event.key == pg.K_F1:
                    if sp_min > -140:
                        sp_min -= 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_UP or event.key == pg.K_F8:
                    if v_max < 0:
                        v_max += 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_DOWN or event.key == pg.K_F7:
                    if v_max > v_min + 5:
                        v_max -= 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_RIGHT or event.key == pg.K_F6:
                    if v_min < v_max - 5:
                        v_min += 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_LEFT or event.key == pg.K_F5:
                    if v_min > -140:
                        v_min -= 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_F10 or event.key == pg.K_RETURN:#elif event.key == pg.K_RETURN:
                    info_phase += 1                 # Jump to phase 3 or phase 4 overlay
                    info_counter = 0                #   (next time)
            #-----------------------------------------------------------------------------		
            elif info_phase == 3:                   # Listen for info phase 3 keys
                if event.key == pg.K_UP or event.key == pg.K_F4:
                    if sp_max < 0:
                        sp_max += 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_DOWN or event.key == pg.K_F3:
                    if sp_max > -140 and sp_max > sp_min + 5:
                        sp_max -= 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_RIGHT or event.key == pg.K_F2:
                    if sp_min < sp_max -5:
                        sp_min += 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_LEFT or event.key == pg.K_F1:
                    if sp_min > -140:
                        sp_min -= 5
                    mygraticule.set_range(sp_min, sp_max)
                    surf_2d_graticule = mygraticule.make()   
                elif event.key == pg.K_UP or event.key == pg.K_F8:
                    if v_max < 0:
                        v_max += 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_DOWN or event.key == pg.K_F7:
                    if v_max > v_min + 5:
                        v_max -= 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_RIGHT or event.key == pg.K_F6:
                    if v_min < v_max - 5:
                        v_min += 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_LEFT or event.key == pg.K_F5:
                    if v_min > -140:
                        v_min -= 5
                    mywf.set_range(v_min,v_max)
                elif event.key == pg.K_F10 or event.key == pg.K_RETURN:#elif event.key == pg.K_RETURN:
                    info_phase = 0                  # Turn OFF overlay
                    info_counter = 0