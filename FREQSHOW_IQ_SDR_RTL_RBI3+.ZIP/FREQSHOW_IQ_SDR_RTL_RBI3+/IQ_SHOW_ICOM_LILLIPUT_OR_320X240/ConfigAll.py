SpMin = -120
SpMax = -60
RtlGain = 50
RtlFrequency = 69006000.0
NSteps = 25
SpeedWF = 80
VMin = -100
VMax= -25
