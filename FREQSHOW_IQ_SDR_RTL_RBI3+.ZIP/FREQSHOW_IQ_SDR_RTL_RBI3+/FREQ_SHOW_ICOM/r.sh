nice -20 python iq.py --size=310 --n_buffers=16 --take=6 --index=2 --rate=48000 --WATERFALL --waterfall_acc=1 --FULLSCREEN
